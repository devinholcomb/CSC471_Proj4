package org.example;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import com.github.javafaker.Faker;
import org.kohsuke.randname.RandomNameGenerator;

import static java.lang.String.format;

public class randomGenerator {

    private static File root = new File("./data");
    private final String fileName;
    private final int lines;

    randomGenerator(String fileName, int lineCount) {
        this.fileName = fileName;
        this.lines = lineCount;
    }

    void generate() throws IOException {
        Path fullPath = new File(root, fileName).toPath();
        // make sure file exists
        Files.createDirectories(fullPath.getParent());
        RandomNameGenerator rng = new RandomNameGenerator(0);
        Faker faker = new Faker();
        try (BufferedWriter bw = Files.newBufferedWriter(fullPath)) {
            for (int i = 0; i < lines; ++i) {

                int month = faker.number().numberBetween(1, 12);
                String s = null;

                if (month < 10) {
                    s = format("0" + "%d", month);
                } else {
                    s = String.valueOf(month);
                }
                int day = faker.number().numberBetween(1, 31);
                String d = null;

                if (day < 10) {
                    d = format("0" + "%d", day);
                } else {
                    d = String.valueOf(day);
                }

                String line = format("%s" + "," + s + d + "%s" + "," + "%s" + "," + "%c" + "," + "%s" + "%n", faker.number().numberBetween(100000000, 999999999), faker.number().numberBetween(1920, 2001),
                        faker.name().firstName(), (char) faker.number().numberBetween(65, 90), faker.name().lastName());

                bw.write(line);
            }
        }
    }

}
