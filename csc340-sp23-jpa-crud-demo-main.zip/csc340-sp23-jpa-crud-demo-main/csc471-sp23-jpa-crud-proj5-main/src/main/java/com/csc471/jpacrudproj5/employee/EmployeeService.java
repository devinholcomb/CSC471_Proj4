package com.csc471.jpacrudproj5.employee;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author devin
 */
@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    public List<Employee> getAllEmployees() {
        return repo.findAll();
    }

    public Employee getEmployee(long employeeSSN) {
        return repo.getReferenceById(employeeSSN);
    }

    public void deleteEmployee(long employeeSSN) {
        repo.deleteById(employeeSSN);
    }

    void saveEmployee(Employee product) {

        repo.save(product);
    }

}
