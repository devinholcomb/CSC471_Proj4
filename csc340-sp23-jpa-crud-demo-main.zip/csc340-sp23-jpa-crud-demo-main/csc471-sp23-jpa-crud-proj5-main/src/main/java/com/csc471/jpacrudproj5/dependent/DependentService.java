package com.csc471.jpacrudproj5.dependent;

import com.csc471.jpacrudproj5.employee.Employee;
import com.csc471.jpacrudproj5.employee.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DependentService {
    @Autowired
    private DependentRepository repo;

    public List<Dependent> getAllDependents() {
        return repo.findAll();
    }

    public Dependent getDependent(long employeeSSN) {
        return repo.getReferenceById(employeeSSN);
    }

    public void deleteDependent(long employeeSSN) {
        repo.deleteById(employeeSSN);
    }

    void saveDependent(Dependent dependent) {

        repo.save(dependent);
    }



}
