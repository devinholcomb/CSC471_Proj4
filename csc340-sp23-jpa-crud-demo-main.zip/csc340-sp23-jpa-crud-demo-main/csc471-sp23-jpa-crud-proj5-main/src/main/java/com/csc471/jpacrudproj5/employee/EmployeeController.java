package com.csc471.jpacrudproj5.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author devin
 */
@Controller
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @GetMapping("/all")
    public String getEmployees(Model model) {
        model.addAttribute("employeeList", employeeService.getAllEmployees());
        return "employee/list-employees";
    }

    @GetMapping("/id={employeeSSN}")
    public String getEmployee(@PathVariable long employeeSSN, Model model) {
        model.addAttribute("employee", employeeService.getEmployee(employeeSSN));
        return "employee/employee-detail";
    }

    @GetMapping("/delete/id={employeeSSN}")
    public String deleteEmployee(@PathVariable long employeeSSN, Model model) {
        employeeService.deleteEmployee(employeeSSN);
        return "redirect:/employee/all";
    }

    @PostMapping("/create")
    public String createEmployee(Employee employee) {

        employeeService.saveEmployee(employee);
        return "redirect:/employee/all";
    }

    @PostMapping("/update")
    public String updateEmployee(Employee employee) {
        employeeService.saveEmployee(employee);
        return "redirect:/employee/all";
    }

    @GetMapping("/new-employee")
    public String newEmployeeForm(Model model) {
        return "employee/new-employee";
    }

    @GetMapping("/update/id={employeeSSN}")
    public String updateEmployeeForm(@PathVariable long employeeSSN, Model model) {
        model.addAttribute("employee", employeeService.getEmployee(employeeSSN));
        return "employee/update-employee";
    }
}
