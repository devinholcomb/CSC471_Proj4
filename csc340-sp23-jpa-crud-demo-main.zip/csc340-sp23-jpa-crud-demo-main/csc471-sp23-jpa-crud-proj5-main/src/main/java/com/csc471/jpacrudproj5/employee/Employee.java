package com.csc471.jpacrudproj5.employee;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author devin
 */

@Entity
@Table(name = "employee")
@NoArgsConstructor
@Getter
@Setter
public class Employee {

    @Id
    private long SSN;
    private String dob;
    private String fname;
    private String minit;
    private String lname;



    public Employee(long SSN, String dob, String fname, String minit, String lname) {
        this.SSN = SSN;
        this.fname = fname;
        this.minit = minit;
        this.lname = lname;
        this.dob = dob;

    }

}
