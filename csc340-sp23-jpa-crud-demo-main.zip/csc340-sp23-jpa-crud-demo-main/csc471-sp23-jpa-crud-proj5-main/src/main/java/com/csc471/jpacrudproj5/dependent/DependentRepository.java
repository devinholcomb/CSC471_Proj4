package com.csc471.jpacrudproj5.dependent;

import com.csc471.jpacrudproj5.employee.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DependentRepository extends JpaRepository<Dependent, Long> {

}
