package com.csc471.jpacrudproj5.dependent;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author devin
 */

@Entity
@Table(name = "dependent")
@NoArgsConstructor
@Getter
@Setter

public class Dependent {

    @Id
    private long SSN;
    private String name;
    private String relationship;

    public Dependent(long SSN, String name, String relationship) {
        this.SSN = SSN;
        this.name = name;
        this.relationship = relationship;
    }
}

