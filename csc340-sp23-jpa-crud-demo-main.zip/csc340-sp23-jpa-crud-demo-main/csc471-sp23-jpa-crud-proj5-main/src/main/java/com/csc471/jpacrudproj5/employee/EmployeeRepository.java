package com.csc471.jpacrudproj5.employee;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author devin
 */
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
