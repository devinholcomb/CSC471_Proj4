package com.csc471.jpacrudproj5.dependent;
import com.csc471.jpacrudproj5.dependent.Dependent;
import com.csc471.jpacrudproj5.dependent.DependentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author devin
 */
@Controller
@RequestMapping("/dependent")
public class DependentController {

    @Autowired
    DependentService dependentService;

    @GetMapping("/all")
    public String getDependents(Model model) {
        model.addAttribute("dependentList", dependentService.getAllDependents());
        return "dependent/list-dependents";
    }

    @GetMapping("/id={dependentSSN}")
    public String getDependent(@PathVariable long dependentSSN, Model model) {
        model.addAttribute("dependent", dependentService.getDependent(dependentSSN));
        return "dependent/dependent-detail";
    }

    @GetMapping("/delete/id={dependentSSN}")
    public String deleteDependent(@PathVariable long dependentSSN, Model model) {
        dependentService.deleteDependent(dependentSSN);
        return "redirect:/dependent/all";
    }

    @PostMapping("/create")
    public String createDependent(Dependent dependent) {

        dependentService.saveDependent(dependent);
        return "redirect:/dependent/all";
    }

    @PostMapping("/update")
    public String updateDependent(Dependent dependent) {
        dependentService.saveDependent(dependent);
        return "redirect:/dependent/all";
    }

    @GetMapping("/new-dependent")
    public String newDependentForm(Model model) {
        return "dependent/new-dependent";
    }

    @GetMapping("/update/id={dependentSSN}")
    public String updateDependentForm(@PathVariable long dependentSSN, Model model) {
        model.addAttribute("dependent", dependentService.getDependent(dependentSSN));
        return "dependent/update-dependent";
    }


}
