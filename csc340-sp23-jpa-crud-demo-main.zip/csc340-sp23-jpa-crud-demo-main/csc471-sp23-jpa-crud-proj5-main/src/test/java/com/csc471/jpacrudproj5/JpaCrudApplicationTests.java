package com.csc471.jpacrudproj5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
